package Assignment5.interfaces;

public interface SecondaryHeading {   
    // marker interface, i.e., nothing to implement
}

