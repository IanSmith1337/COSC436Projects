package Assignment5.interfaces;

public interface Receipt {   
    // type of all receipt components (i.e., BasicReceipt and receipt decorators)
	public void prtReceipt();
}
