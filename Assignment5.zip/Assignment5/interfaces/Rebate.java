package Assignment5.interfaces;

public interface Rebate {   
    // marker interface, i.e., nothing to implement
}
