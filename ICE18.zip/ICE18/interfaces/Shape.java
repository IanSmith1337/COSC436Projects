package ICE18.interfaces;

public interface Shape {
    public void draw();
}
