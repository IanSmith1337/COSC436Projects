package ICE18.interfaces;

public interface Color {
    public void fill();
}
