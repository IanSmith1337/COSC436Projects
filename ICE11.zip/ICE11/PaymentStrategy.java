package ICE11;

public interface PaymentStrategy {
    public void pay(int amount);
}
