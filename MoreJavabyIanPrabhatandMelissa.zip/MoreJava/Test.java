package MoreJava;

public class Test {
    
    public static void main(String[] args) {

        ChildClass childObj = new ChildClass();
            
    }

}
