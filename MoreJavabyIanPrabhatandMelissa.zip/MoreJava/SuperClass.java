package MoreJava;

public class SuperClass {

    public SuperClass() {
        System.out.println("This is a super class");
    }
    
}