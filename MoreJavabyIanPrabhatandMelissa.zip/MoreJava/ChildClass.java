package MoreJava;



public class ChildClass extends SuperClass {

     

    public ChildClass(){
        super();
        System.out.println("This is Child Class ");
    }

}