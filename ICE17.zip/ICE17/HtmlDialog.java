package ICE17;

public class HtmlDialog extends Dialog {

    public Button createButton() { 
        return new HtmlButton(); 
    }
}
