package ICE17;

public interface Button {
    public abstract void render();

    public abstract void onClick();
    
}
