package ICE14 ; 

public interface Command {
  public void execute();
}

