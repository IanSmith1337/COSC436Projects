package ICE15;

public interface AlarmListener {
    public void alarm();
}
