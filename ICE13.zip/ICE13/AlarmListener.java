package ICE13;

public interface AlarmListener {
    public void alarm();
}
