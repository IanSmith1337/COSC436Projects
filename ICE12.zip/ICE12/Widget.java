package ICE12;

public interface Widget {
    public void draw();   
}
