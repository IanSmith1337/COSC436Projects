package ICE16;

interface Shape {
	void draw(int x, int y, int z, int j);
}
