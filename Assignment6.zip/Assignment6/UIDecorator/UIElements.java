package Assignment6.UIDecorator;

public interface UIElements {
    void create();
}
