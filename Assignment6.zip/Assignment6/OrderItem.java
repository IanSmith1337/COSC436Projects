package Assignment6;

public class OrderItem {
    private int itemNumber;

    public OrderItem(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    public int getItemNumber(){
        return itemNumber;
    }


}