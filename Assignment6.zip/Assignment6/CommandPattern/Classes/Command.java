package Assignment6.CommandPattern.Classes;

public interface Command {
    public Object execute();
}
