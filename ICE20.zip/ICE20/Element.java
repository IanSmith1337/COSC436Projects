package ICE20;

public interface Element{
void accept (Visitor v);
}
