package Composite;

public interface AbstractFile {
    abstract void ls();
}