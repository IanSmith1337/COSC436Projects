package MoreMoreJava.Cars;

public class Truck extends Car {
    public void m1() {
        System.out.println("truck 1");
    }
}