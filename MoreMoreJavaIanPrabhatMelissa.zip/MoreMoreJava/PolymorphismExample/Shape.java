package MoreMoreJava.PolymorphismExample;

public class Shape {
    
}